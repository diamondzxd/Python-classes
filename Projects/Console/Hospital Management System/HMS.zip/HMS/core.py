import os

def clrscr():
	os.system('cls')

def Header():
	clrscr()
	print("\n\n")
	print("\t\t\t\tJaipur Golden Hospital, Rohini")
	print(" " + "-"*118)
	print("")
